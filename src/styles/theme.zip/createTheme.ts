import { light } from "@/styles/theme/modes/light";
import { dark } from "@/styles/theme/modes/dark";
import { colors } from "./colors";
import { red } from "./red";
import { blue } from "./blue";
import { brown } from "./brown";

export type Mode = "light" | "dark";
export type Accent = "red" | "blue" | "brown";

const accentThemes = {
  red,
  blue,
  brown,
};

export interface AppTheme {
  mode: "light" | "dark";
  bg: string;
  surface: string;
  text: string;
  textMuted: string;
  border: string;
  colors: typeof colors & {
    primary: string;
    secondary: string;
    primaryHover: string;
  };
  icon: string;
  line: string;
  footerBg: string;
  sidebarBg: string;
  sidebarBgDark: string;
  menuActiveBg: string;
  accent: typeof red | typeof blue | typeof brown;
}

export const createTheme = (mode: Mode, accent: Accent = "blue"): AppTheme => {
  const base = mode === "dark" ? dark : light;
  const accentColors = accentThemes[accent];

  return {
    ...base,
    colors: {
      ...colors,
      primary: accentColors.primary,
      secondary: accentColors.secondary,
      primaryHover: accentColors.bgHover,
    },
    accent: accentColors,
    sidebarBg:
      mode === "dark" ? accentColors.sidebarBgDark : accentColors.sidebarBg, // 추가
    sidebarBgDark: accentColors.sidebarBgDark, // 추가
    menuActiveBg: accentColors.menuActiveBg,
  };
};

import { colors } from "@/styles/theme/colors";

export const brown = {
  name: "brown" as const,
  primary: "#92400E",
  secondary: "#78350F",
  bgHover: "#451A03",
  textColor: colors.white,
  logoutBg: "#92400E",
  logoutText: colors.white,
  logoutHoverBg: "#78350F",
  sidebarBg: "#fff", // light mode sidebar
  sidebarBgDark: "#78350F", // dark mode sidebar
  iconDark: "#92400E",
  menuActiveBg: "#78350F",
};

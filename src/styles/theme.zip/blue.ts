import { colors } from "@/styles/theme/colors";

export const blue = {
  name: "blue" as const,
  primary: "#3B82F6",
  secondary: "#2563EB",
  bgHover: "#1D4ED8",
  textColor: colors.white,
  logoutBg: "#3B82F6",
  logoutText: colors.white,
  logoutHoverBg: "#2563EB",
  sidebarBg: "#fff", // light mode sidebar
  sidebarBgDark: "#1E3A8A", // dark mode sidebar
  iconDark: "#3B82F6",
  menuActiveBg: "#f4f8ff",
};

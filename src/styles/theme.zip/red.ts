import { colors } from "@/styles/theme/colors";

export const red = {
  name: "red" as const,
  bg: "#E21A22",
  primary: colors.red,
  secondary: "#E21A22",
  bgHover: "#D5181F",
  textColor: colors.white,
  logoutBg: colors.red,
  logoutText: colors.white,
  logoutHoverBg: "#D5181F",
  sidebarBg: "#fff", // light mode sidebar
  sidebarBgDark: "#7F1D1D", // dark mode sidebar
  iconDark: "#D5181F",
  menuActiveBg: "#FFF4F5",
};
